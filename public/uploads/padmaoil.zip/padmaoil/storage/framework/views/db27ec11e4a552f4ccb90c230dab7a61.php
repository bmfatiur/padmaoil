 <!-- featured-area start -->
 <div class="featured-area featured-area2">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="featured-active2 owl-carousel next-prev-style">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="featured-wrap">
                            <div class="featured-img">
                                <img src="<?php echo e(asset('uploads/category')); ?>/<?php echo e($category->category_image); ?>" alt="">
                                <div class="featured-content">
                                    <a href="<?php echo e(route('shop.page')); ?>"><?php echo e($category->title); ?></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- featured-area end -->
<?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/frontend/pages/widgets/featured.blade.php ENDPATH**/ ?>