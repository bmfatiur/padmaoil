<?php $__env->startSection('frontendtitle'); ?> Customer Dashboard Page <?php $__env->stopSection(); ?>

<?php $__env->startSection('frontend_content'); ?>
   <?php echo $__env->make('frontend.layouts.inc.breadcrumb', ['pagename' => 'Customer Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div class="col-lg-12 col-md-12 m-auto" >
    <div class="card">
        <div class="card-header tx-white bg-teal">
            <h4 class="card-title tx-white">Customer Name : <?php echo e($user->name); ?></h4>
            <div>
                <br>
                <h3>Acoount Balance: <b><?php if(Session::has('user') && array_key_exists('balance', Session::get('user'))): ?><strong><?php echo e(Session::get('user')['balance']); ?></strong>
                    <?php else: ?>
                        <!-- Handle the case where 'user' or 'balance' is not set in the session -->
                        <p>not set</p>
                    <?php endif; ?></b> </h3>
                    
            </div>
            <div class="m-5">
                <p>Enter Your Token Code if You Have One</p>
                <div class="cupon-wrap">
                    <form action="<?php echo e(route('customer.tokenapply')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="token_name" placeholder="Token Code" class="form-control">
                        <button type="submit" class="btn btn-danger">Recharge</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="card-body ">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/frontend/pages/customer-dashboard.blade.php ENDPATH**/ ?>