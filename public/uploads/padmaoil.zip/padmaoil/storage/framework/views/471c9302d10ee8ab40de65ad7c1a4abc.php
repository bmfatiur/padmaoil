<?php $__env->startSection('title'); ?> Order Index <?php $__env->stopSection(); ?>

<?php $__env->startPush('admin_style'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">

<style>
    .dataTables_length{
        padding: 20px 0;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <h1>Order List Table</h1>

    <div class="col-12">
        <div class="table-responsive my-2">
            <table class="table table-hover" id="dataTable">
                <thead class="text-primary">
                    <th>#</th>
                    <th>View Details</th>
                    <th>order date</th>
                    <th>Sub total(BDT)</th>
                    <th>Discount(BDT)</th>
                    <th>Total (BDT)</th>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td> <?php echo e($loop->index+1); ?> </td>
                            <td>
                                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modal<?php echo e($order->id); ?>">Order Details</button>
                                <div class="modal fade" id="modal<?php echo e($order->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modal<?php echo e($order->id); ?>Title" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content" style="width: 800px;">
                                            <div class="modal-header">
                                            <h5 class="modal-title" id="#modal<?php echo e($order->id); ?>Title">Order Number #<?php echo e($order->id); ?></h5>
                                            <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="container-fluid">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <table class="table table-striped table-inverse table-responsive">
                                                            <thead class="thead-inverse">
                                                                <tr>
                                                                    <th>#</th>
                                                                    <th>Product Name</th>
                                                                    <th>Quantity</th>
                                                                    <th>Unit Price</th>
                                                                    <th>Sub total</th>
                                                                </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td><?php echo e($loop->index+1); ?></td>
                                                                        <td><?php echo e($item->product->name); ?></td>
                                                                        <td><?php echo e($item->product_qty); ?></td>
                                                                        <td><?php echo e($item->product_price); ?></td>
                                                                        <td><?php echo e($item->product_price*$item->product_qty); ?></td>
                                                                    </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr class="mb-5">
                                                                        <td colspan="4">
                                                                            Total Payable Amount:
                                                                        </td>
                                                                        <td><strong class="fw-bold text-danger"> ৳<?php echo e($order->total); ?></strong></td>
                                                                    </tr>
                                                                    <tr class="mt-5">
                                                                        <td colspan="50">
                                                                            <p class="text-primary">Billing Address:</p>
                                                                            <p>Recipent Name: <?php echo e($order->billing->name); ?></p>
                                                                            <p>Mobile Number: <?php echo e($order->billing->phone_number); ?></p>
                                                                            <p>Address: <?php echo e($order->billing->address); ?></p>
                                                                            <p>Upazila: <?php echo e($order->billing->upazila->name); ?>

                                                                            Distrcit: <?php echo e($order->billing->district->name); ?></p>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($order->created_at->format('d-M-Y H:i:s')); ?></td>
                            <td><?php echo e($order->sub_total); ?></td>
                            <td><?php echo e($order->discount_amount); ?>(<?php echo e($order->coupon_name); ?>)</td>
                            <td><?php echo e($order->total); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="50">
                                <p class="text-center">No order Found !!!</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($orders->links()); ?>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin_script'); ?>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.20/dist/sweetalert2.all.min.js"></script>

<script>
    $(document).ready(function () {
    $('#dataTable').DataTable({
        pagingType: 'first_last_numbers',
    });

    $('.show_confirm').click(function(event){
        let form = $(this).closest('form');

        event.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
                Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
                )
            }
            })
    })
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/backend/pages/order/index.blade.php ENDPATH**/ ?>