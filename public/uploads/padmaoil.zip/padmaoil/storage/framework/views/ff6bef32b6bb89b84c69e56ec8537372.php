<?php $__env->startSection('frontendtitle'); ?> Shop Page <?php $__env->stopSection(); ?>

<?php $__env->startSection('frontend_content'); ?>
   <?php echo $__env->make('frontend.layouts.inc.breadcrumb', ['pagename' => 'Shop'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- product-area start -->
<div class="product-area pt-100">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-12">
                <div class="product-menu">
                    <ul class="nav justify-content-center">
                        <li>
                            <a class="active" data-toggle="tab" href="#all">All product</a>
                        </li>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a data-toggle="tab" href="#<?php echo e($category->slug); ?>"><?php echo e($category->title); ?></a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
        </div>
        <div class="tab-content">

            <div class="tab-pane active" id="all">
                <ul class="row">
                    <?php $__currentLoopData = $allproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="col-xl-3 col-lg-4 col-sm-6 col-12">
                        <div class="product-wrap">
                            <div class="product-img">
                                <span>Sale</span>
                                <img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($product->product_image); ?>" alt="">
                                <div class="product-icon flex-style">
                                    <ul>
                                        <li><a data-toggle="modal" data-target="#exampleModalCenter" href="javascript:void(0);"><i class="fa fa-eye"></i></a></li>
                                        <li><a href="wishlist.html"><i class="fa fa-heart"></i></a></li>
                                        <li><a href="<?php echo e(route('productdetail.page', ['product_slug' => $product->slug])); ?>"><i class="fa fa-shopping-bag"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product-content">
                                <h3><a href="<?php echo e(route('productdetail.page', ['product_slug' => $product->slug])); ?>"><?php echo e($product->name); ?></a></h3>
                                <p class="pull-left">৳<?php echo e($product->product_price); ?>


                                </p>
                                <ul class="pull-right d-flex">
                                    <?php for($i = 0; $i < $product->product_rating; $i++): ?>
                                        <li><i class="fa fa-star"></i></li>
                                    <?php endfor; ?>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <div class="col-12 text-center d-flex justify-content-center">
                    <div class="py-3">
                        <?php echo e($allproducts->links()); ?>

                    </div>
                </div>
            </div>

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="tab-pane" id="<?php echo e($category->slug); ?>">
                    <ul class="row">
                        <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="col-xl-3 col-lg-4 col-sm-6 col-12">
                            <div class="product-wrap">
                                <div class="product-img">
                                    <span>Sale</span>
                                    <img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($cproduct->product_image); ?>" alt="">
                                    <div class="product-icon flex-style">
                                        <ul>
                                            <li><a data-toggle="modal" data-target="#exampleModalCenter" href="javascript:void(0);"><i class="fa fa-eye"></i></a></li>
                                            <li><a href="wishlist.html"><i class="fa fa-heart"></i></a></li>
                                            <li><a href="<?php echo e(route('productdetail.page', ['product_slug' => $cproduct->slug])); ?>"><i class="fa fa-shopping-bag"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="product-content">
                                    <h3><a href="<?php echo e(route('productdetail.page', ['product_slug' => $cproduct->slug])); ?>"><?php echo e($cproduct->name); ?></a></h3>
                                    <p class="pull-left">$<?php echo e($cproduct->product_price); ?>


                                    </p>
                                    <ul class="pull-right d-flex">
                                        <?php for($i = 0; $i < $cproduct->product_rating; $i++): ?>
                                        <li><i class="fa fa-star"></i></li>
                                        <?php endfor; ?>
                                    </ul>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>


    </div>
</div>
<!-- product-area end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/frontend/pages/shop.blade.php ENDPATH**/ ?>