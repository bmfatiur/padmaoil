<!-- .breadcumb-area start -->
<div class="breadcumb-area bg-img-4 ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcumb-wrap text-center">
                    <h2><?php echo e($pagename); ?> Page</h2>
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li><span><?php echo e($pagename); ?></span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- .breadcumb-area end -->
<?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/frontend/layouts/inc/breadcrumb.blade.php ENDPATH**/ ?>