<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/frontend')); ?>/images/favicon.png">
<!-- Place favicon.ico in the root directory -->
<!-- all css here -->
<!-- bootstrap v4.0.0-beta.2 css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/bootstrap.min.css">
<!-- owl.carousel.2.0.0-beta.2.4 css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/owl.carousel.min.css">
<!-- font-awesome v4.6.3 css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/font-awesome.min.css">
<!-- flaticon.css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/flaticon.css">
<!-- jquery-ui.css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/jquery-ui.css">
<!-- metisMenu.min.css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/metisMenu.min.css">
<!-- swiper.min.css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/swiper.min.css">
<!-- style css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/styles.css">
<!-- responsive css -->
<link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/responsive.css">
<!-- modernizr css -->
<script src="<?php echo e(asset('assets/frontend')); ?>/js/vendor/modernizr-2.8.3.min.js"></script>

<link rel="stylesheet" href="http://cdn.bootcss.com/toastr.js/latest/css/toastr.min.css">
<?php echo $__env->yieldPushContent('frontend_style'); ?>
<?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/frontend/layouts/inc/style.blade.php ENDPATH**/ ?>