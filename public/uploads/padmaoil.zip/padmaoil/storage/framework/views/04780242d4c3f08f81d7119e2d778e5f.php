 <!-- testmonial-area start -->
 <div class="testmonial-area testmonial-area2 bg-img-2 black-opacity">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="test-title text-center">
                    <h2>What Our client Says</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-10 offset-md-1 col-12">
                <div class="testmonial-active owl-carousel">
                    <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="test-items test-items2">
                            <div class="test-content">
                                <p><?php echo e($testimonial->client_message); ?></p>
                                <h2><?php echo e($testimonial->client_name); ?></h2>
                                <p><?php echo e($testimonial->client_designation); ?></p>
                            </div>
                            <div class="test-img2">
                                <img src="<?php echo e(asset('uploads/testimonials')); ?>/<?php echo e($testimonial->client_image); ?>" alt="">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- testmonial-area end -->
<?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/frontend/pages/widgets/testimonial.blade.php ENDPATH**/ ?>