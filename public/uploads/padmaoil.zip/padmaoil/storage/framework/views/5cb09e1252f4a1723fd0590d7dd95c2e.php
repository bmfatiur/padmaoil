    <!-- header-area start -->
    <header class="header-area">
        <div class="header-top bg-2">
            <div class="fluid-container">
                <div class="row">
                    <div class="col-md-6 col-12">
                        <ul class="d-flex header-contact">
                            <li><i class="fa fa-phone"></i> +880 123456789</li>
                            <li><i class="fa fa-envelope"></i> support@padma.com</li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-12">
                        <ul class="d-flex account_login-area">
                            <?php if(auth()->guard()->check()): ?>
                            <li>
                                <a href="javascript:void(0);"><i class="fa fa-user"></i> My Account <i
                                        class="fa fa-angle-down"></i></a>
                                <ul class="dropdown_style">
                                    <li><a href="<?php echo e(route('customer.dashboard')); ?>">Dashboard</a></li>
                                    <li><a href="<?php echo e(route('cart.page')); ?>">Cart</a></li>
                                    <li><a href="<?php echo e(route('customer.logout')); ?>">Logout</a></li>
                                </ul>
                            </li>
                            <?php endif; ?>
                            <?php if(auth()->guard()->guest()): ?>
                            <li><a href="<?php echo e(route('login.page')); ?>"> Login </a></li>
                            <li><a href="<?php echo e(route('register.page')); ?>"> Register </a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-bottom">
            <div class="fluid-container">
                <div class="row">
                    <div class="col-lg-3 col-md-7 col-sm-6 col-6">
                        <div class="logo">
                            <a href="<?php echo e(route('home')); ?>">
                                <img src="assets/frontend/images/logo.png" alt="Padma Oill Mill Ltd">
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-7 d-none d-lg-block">
                        <nav class="mainmenu">
                            <ul class="d-flex">
                                <li class="active"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li><a href="<?php echo e(route('home')); ?>">About</a></li>
                                <li>
                                    <a href="javascript:void(0);">Shop <i class="fa fa-angle-down"></i></a>
                                    <ul class="dropdown_style">
                                        <li><a href="<?php echo e(route('shop.page')); ?>">Shop Page</a></li>
                                        <li><a href="<?php echo e(route('cart.page')); ?>">Shopping cart</a></li>
                                    </ul>
                                </li>
                                
                                
                                <li><a href="<?php echo e(route('home')); ?>">Contact</a></li>
                            </ul>
                        </nav>
                    </div>
                    <div class="col-md-4 col-lg-2 col-sm-5 col-4">
                        <ul class="search-cart-wrapper d-flex">
                            <li class="search-tigger"><a href="javascript:void(0);"><i class="flaticon-search"></i></a>
                            </li>
                            
                                
                            
                            <li>
                                <a href="javascript:void(0);"><i class="flaticon-shop"></i> <span>3</span></a>
                                <ul class="cart-wrap dropdown_style">
                                    <?php
                                        $carts = \Gloudemans\Shoppingcart\Facades\Cart::content();
                                        $total_price = \Gloudemans\Shoppingcart\Facades\Cart::subtotal();
                                    ?>

                                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="cart-items">
                                        <div class="cart-img">
                                            <img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($item->options->product_image); ?>" alt="" class="img-fluid rounded" style="width: 60px;">
                                        </div>
                                        <div class="cart-content text-white">
                                            <a href="<?php echo e(route('cart.page')); ?>"><?php echo e($item->name); ?></a>
                                            <span>QTY : <?php echo e($item->qty); ?></span>
                                            <p>৳<?php echo e($item->qty*$item->price); ?></p>
                                            <a href="<?php echo e(route('removefrom.cart',['cart_id' => $item->rowId])); ?>">
                                                <i class="fa fa-times"></i>
                                            </a>
                                        </div>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <li>Subtotol: <span class="pull-right">$<?php echo e($total_price); ?></span></li>
                                    
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-1 col-sm-1 col-2 d-block d-lg-none">
                        <div class="responsive-menu-tigger">
                            <a href="javascript:void(0);">
                                <span class="first"></span>
                                <span class="second"></span>
                                <span class="third"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- responsive-menu area start -->
            <div class="responsive-menu-area">
                <div class="container">
                    <div class="row">
                        <div class="col-12 d-block d-lg-none">
                            <ul class="metismenu">
                                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                <li><a href="<?php echo e(route('home')); ?>">About</a></li>
                                <li class="sidemenu-items">
                                    <a class="has-arrow" aria-expanded="false" href="javascript:void(0);">Shop </a>
                                    <ul aria-expanded="false">
                                        <li><a href="<?php echo e(route('shop.page')); ?>">Shop Page</a></li>
                                        <li><a href="<?php echo e(route('cart.page')); ?>">Shopping cart</a></li>
                                        <li><a href="<?php echo e(route('cart.page')); ?>">Checkout</a></li>
                                        
                                    </ul>
                                </li>
                                <li class="sidemenu-items">
                                    <a class="has-arrow" aria-expanded="false" href="javascript:void(0);">Pages </a>
                                    <ul aria-expanded="false">
                                        <li><a href="<?php echo e(route('home')); ?>">About Page</a></li>
                                        <li><a href="<?php echo e(route('cart.page')); ?>">Shopping cart</a></li>
                                        <li><a href="<?php echo e(route('cart.page')); ?>">Checkout</a></li>
                                        
                                    </ul>
                                </li>
                                
                                <li><a href="<?php echo e(route('home')); ?>">Contact</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- responsive-menu area start -->
        </div>
    </header>
    <!-- header-area end -->
<?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/frontend/layouts/inc/header.blade.php ENDPATH**/ ?>