<!DOCTYPE html>
<html lang="en" data-footer="true"
    data-override='{"attributes": {"placement": "vertical", "layout": "boxed" }, "storagePrefix": "ecommerce-platform"}'>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <title>Admin | <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="Ecommerce Dashboard" />

    <?php echo $__env->make('backend.layouts.inc.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
    <div id="root">
        <div id="nav" class="nav-container d-flex">
            <div class="nav-content d-flex">
               <?php echo $__env->make('backend.layouts.inc.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('backend.layouts.inc.user-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('backend.layouts.inc.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
            <div class="nav-shadow"></div>
        </div>

        <main>
            <div class="container" style="margin-top: 50px;">
               <?php echo $__env->yieldContent('admin_content'); ?>
            </div>
        </main>


        <?php echo $__env->make('backend.layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo $__env->make('backend.layouts.inc.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/backend/layouts/master.blade.php ENDPATH**/ ?>