 <!-- product-area start -->
 <div class="product-area">
    <div class="fluid-container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2>Our Latest Product</h2>
                    <img src="<?php echo e(asset('assets/frontend')); ?>/images/section-title.png" alt="">
                </div>
            </div>
        </div>
        <ul class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="col-xl-3 col-lg-4 col-sm-6 col-12">
                <div class="product-wrap">
                    <div class="product-img">
                        <span>Sale</span>
                        <img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($product->product_image); ?>" alt="">
                        <div class="product-icon flex-style">
                            <ul>
                                <li><a data-toggle="modal" data-target="#exampleModalCenter" href="javascript:void(0);"><i class="fa fa-eye"></i></a></li>
                                <li><a href="<?php echo e(route('productdetail.page', ['product_slug' => $product->slug])); ?>"><i class="fa fa-heart"></i></a></li>
                                <li><a href="<?php echo e(route('productdetail.page', ['product_slug' => $product->slug])); ?>"><i class="fa fa-shopping-bag"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="product-content">
                        <h3><a href="<?php echo e(route('productdetail.page', ['product_slug' => $product->slug])); ?>"><?php echo e($product->name); ?></a></h3>
                        <p class="pull-left">$<?php echo e($product->product_price); ?>


                        </p>
                        <ul class="pull-right d-flex">
                            <?php for($i = 0; $i < $product->product_rating; $i++): ?>
                                <li><i class="fa fa-star"></i></li>
                            <?php endfor; ?>
                        </ul>
                    </div>
                </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-12 text-center d-flex justify-content-center">
                <div class="py-3">
                    <?php echo e($products->links()); ?>

                </div>
            </div>
        </ul>
    </div>
</div>
<!-- product-area end -->
<?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/frontend/pages/widgets/latest-product.blade.php ENDPATH**/ ?>