<?php $__env->startSection('title'); ?> Token Index <?php $__env->stopSection(); ?>

<?php $__env->startPush('admin_style'); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">

<style>
    .dataTables_length{
        padding: 20px 0;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <h1>Token List Table</h1>
    <div class="col-12">
        <div class="d-flex justify-content-end">
            <a href="<?php echo e(route('coupon2.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus-circle"></i>
                Add New Token
            </a>
        </div>
    </div>
    <div class="col-12">
        <div class="table-responsive my-2">
            <table class="table table-bordered table-striped" id="dataTable">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Amount</th>
                    <th scope="col">Token Name</th>
                    <th scope="col">Options</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($coupon->isActive): ?>
                            <tr>
                                <th scope="row"><?php echo e($coupons->firstItem()+$loop->index); ?></th>
                                <td><?php echo e($coupon->amount); ?></td>
                                <td><?php echo e($coupon->coupon_name); ?></td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        setting
                                        </button>
                                        <ul class="dropdown-menu">
                                        <li>
                                            <form action="<?php echo e(route('coupon2.destroy', $coupon->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="dropdown-item show_confirm" type="submit"><i class="fas fa-trash"></i> Delete</a></button>
                                            </form>
                                        </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin_script'); ?>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.4.20/dist/sweetalert2.all.min.js"></script>

<script>
    $(document).ready(function () {
    $('#dataTable').DataTable({
        pagingType: 'first_last_numbers',
    });

    $('.show_confirm').click(function(event){
        let form = $(this).closest('form');

        event.preventDefault();
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
                Swal.fire(
                'Deleted!',
                'Your Token has been deleted.',
                'success'
                )
            }
            })
    })
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/backend/pages/coupon2/index.blade.php ENDPATH**/ ?>