<?php $__env->startSection('frontendtitle'); ?> Cart Page <?php $__env->stopSection(); ?>

<?php $__env->startSection('frontend_content'); ?>
   <?php echo $__env->make('frontend.layouts.inc.breadcrumb', ['pagename' => 'Cart'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Cart Page Area-->
<div class="cart-area ptb-100">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <table class="table-responsive cart-wrap">
                    <thead>
                        <tr>
                            <th class="images">Image</th>
                            <th class="product">Product</th>
                            <th class="ptice">Price</th>
                            <th class="quantity">Quantity</th>
                            <th class="total">Total</th>
                            <th class="remove">Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="images"><img src="<?php echo e(asset('uploads/product_photos')); ?>/<?php echo e($cartitem->options->product_image); ?>" alt=""></td>
                            <td class="product"><a href="single-product.html"><?php echo e($cartitem->name); ?></a></td>
                            <td class="ptice">৳<?php echo e($cartitem->price); ?></td>
                            <td class="quantity cart-plus-minus">
                                <input type="text" value="<?php echo e($cartitem->qty); ?>">
                            <div class="dec qtybutton">-</div><div class="inc qtybutton">+</div></td>
                            <td class="total">৳<?php echo e($cartitem->price*$cartitem->qty); ?></td>
                            <td class="remove">
                                <a href="<?php echo e(route('removefrom.cart',['cart_id' => $cartitem->rowId])); ?>">
                                    <i class="fa fa-times"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </tbody>
                </table>
                <div class="row mt-60">
                    <div class="col-xl-4 col-lg-5 col-md-6 ">
                        <div class="cartcupon-wrap">
                            <ul class="d-flex">
                                
                                <li><a href="<?php echo e(route('shop.page')); ?>">Continue Shopping</a></li>
                            </ul>
                            <h3>Coupon</h3>
                            <p>Enter Your Cupon Code if You Have One</p>
                            <div class="cupon-wrap">
                                <form action="<?php echo e(route('customer.couponapply')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="coupon_name" placeholder="Cupon Code" class="form-control">
                                    <button type="submit" class="btn btn-danger">Apply Coupon</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 offset-xl-5 col-lg-4 offset-lg-3 col-md-6">
                        <div class="cart-total text-right">
                            <h3>Cart Totals</h3>
                            <p>
                                <?php if(Session::has('coupon')): ?>
                                <a class="p-1" href="<?php echo e(route('customer.couponremove', 'coupon_name')); ?>"> <i class="fa fa-times">
                                </i></a>

                                <b> <?php echo e(Session::get('coupon')['name']); ?> </b> is Applied
                                <?php endif; ?>
                            </p>
                            <ul>
                                <?php if(Session::has('coupon')): ?>
                                    <li><span class="pull-left">Discount Amount: </span>৳<?php echo e(Session::get('coupon')['discount_amount']); ?></li>
                                    <li><span class="pull-left"> Total: </span>৳ <?php echo e(Session::get('coupon')['balance']); ?> <del class="text-danger">৳ <?php echo e(Session::get('coupon')['cart_total']); ?></del></li>
                                <?php else: ?>
                                    <li><span class="pull-left">Subtotal: </span>৳<?php echo e($total_price); ?></li>
                                    <li><span class="pull-left"> Total: </span> ৳<?php echo e($total_price); ?></li>
                                <?php endif; ?>
                            </ul>
                            <a href="<?php echo e(route('customer.checkoutpage')); ?>">Proceed to Checkout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Cart Page Area-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/frozen/Assistant/Document/Code/Project/padmaoil/resources/views/frontend/pages/shopping-cart.blade.php ENDPATH**/ ?>