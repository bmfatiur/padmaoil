<?php

namespace App\Http\Controllers\Frontend;

use Carbon\Carbon;
use App\Models\User;
use App\Models\Order;
use App\Models\Billing;
use App\Models\Product;
use App\Models\Upazila;
use App\Models\District;
use App\Models\OrderDetails;
use Illuminate\Http\Request;
use App\Mail\PurchaseConfirm;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use App\Http\Requests\OrderStoreRequest;
use Gloudemans\Shoppingcart\Facades\Cart;

class CheckoutController extends Controller
{
    public function checkoutPage()
    {
        $carts = Cart::content();
        $total_price = Cart::subtotal();
        $districts = District::select('id','name','bn_name')->get();
        return view('frontend.pages.checkout', compact(
            'carts',
            'total_price',
            'districts'
        ));
    }

    public function loadUpazillaAjax($district_id)
    {
        $upazilas = Upazila::where('district_id', $district_id)->select('id','name')->get();
        return response()->json($upazilas, 200);
    }

    public function placeOrder(OrderStoreRequest $request)
    {
        // dd($request->all());

        // Insert all inform of billing
        $billing = Billing::create([
            'name' => $request->name,
            'email' => $request->email,
            'phone_number' => $request->phone,
            'district_id' => $request->district_id,
            'upazila_id' => $request->upazila_id,
            'address' => $request->address,
            'order_notes' => $request->order_notes,
        ]);

        // Order Table data insert
        $order = Order::create([
            'user_id' => Auth::id(),
            'billing_id' => $billing->id,
            'sub_total' => Session::get('coupon')['cart_total'] ?? round(Cart::subtotalFloat()),
            'discount_amount' => Session::get('coupon')['discount_amount'] ?? 0,
            'coupon_name' => Session::get('coupon')['name'] ?? '',
            'total' => Session::get('coupon')['balance'] ?? round(Cart::subtotalFloat()),
        ]);


        //Order details table data insert using cart_items helpers
        foreach (Cart::content() as $cart_item) {
            OrderDetails::create([
                'order_id' => $order->id,
                'user_id' => Auth::id(),
                'product_id' => $cart_item->id,
                'product_qty' => $cart_item->qty,
                'product_price' => $cart_item->price,
            ]);

            // Update product table with decrement quantity
            Product::findOrFail($cart_item->id)->decrement('product_stock', $cart_item->qty);
        }

        //account balance updated
        $user_balance = Session::get('user')['balance'];
        $coupon_balance = Session::get('total');

        if ($user_balance >= $coupon_balance) {
            $available = $user_balance - $coupon_balance;
            Session::put('user',[
                'email' => Session::get('user')['email'],
                'balance' => $available,
            ]);
            $mail = Session::get('user')['email'];
            $user = User::where('email', $mail)->first();
            if($user){
                $user->update([
                    'balance' => $available,
                ]);
            }else{
                Toastr::error('Payment Error!!', 'Error');
            }


            // forceDelete from cart table
            Cart::destroy();
            Session::forget('coupon');


            // Noew get order with details information to send mail
            $order = Order::whereId($order->id)->with(['billing', 'orderdetails'])->get();

            // Now Send Mail
            Mail::to($request->email)->send(new PurchaseConfirm($order));

            Toastr::success('Your Order placed successfully!!!!','Success');

            return redirect()->route('cart.page');
        } else {
            Toastr::error('Invalid Action/Token! Check');
            return redirect()->back();
        }
    }
}
